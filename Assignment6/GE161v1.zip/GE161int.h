#include <string>

#include "Windows.h"
#include "SDL.h"
#include "SDL_image.h"

// Helper function prototypes
void fatalSDLError(std::string message);
void fatalSDLError(std::string message1, std::string message2);
void debugOut(std::string message);

