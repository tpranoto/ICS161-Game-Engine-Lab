#include "Scene.h"

GE161::Scene::Scene()
{
}


GE161::Scene::~Scene()
{
}
