#include "EventListener.h"


GE161::EventListener::EventListener()
{
}


void GE161::EventListener::onEvent(Event& event)
{
}
