#include "PongGamePlayScene.h"

#include <stdlib.h>		// srand, rand
#include <time.h>		// time


//PongGamePlayScene.cpp

PongGamePlayScene::PongGamePlayScene(Pong* pong) :
theGame(pong)
{
}

PongGamePlayScene::~PongGamePlayScene()
{
	delete ball;
}

bool PongGamePlayScene::setup()
{
	// Rolling ball sprite sheet is from http://www.java-gaming.org/index.php?topic=21935.0.
	// It has 32 64x64 frames.

	// Start the ball with its upper left in the middle of the window.
	ball = new GE161::GameObject(
		theGame->window()->clientWidth() / 2, theGame->window()->clientHeight() / 2);
	frameWidth_ = 64;
	frameHeight_ = 64;
	GE161::Sprite* ballSpriteSheet = new GE161::Sprite(frameWidth_, frameHeight_);
	for (int row = 0; row < 4; row++)
	{
		for (int column = 0; column < 8; column++)
		{
			int f = ballSpriteSheet->makeFrame(
				GE161::Game::basePath() + "RollingBall.png",
				column*frameWidth_, row*frameHeight_);
			ballSpriteSheet->addFrameToSequence("Rolling", f);
		}
	}
	ball->attachSprite(ballSpriteSheet);

	x_delta = y_delta = 1;
	bounceCount_ = 0;

	// seed the random number generator with the current time
	srand(static_cast<unsigned int>(time(NULL)));		

	return true;
}

int PongGamePlayScene::draw()
{
	ball->moveX(x_delta);
	ball->moveY(y_delta);
	ball->draw("Rolling");
	// If the ball has hit an edge, bounce randomly.
	if (ball->getX() < 0)
	{
		x_delta = rand() % 3 + 1;
		bounceCount_++;
	}
	if (ball->getY() < 0)
	{
		y_delta = rand() % 3 + 1;
		bounceCount_++;
	}
	if (ball->getX() + frameWidth_ >= theGame->window()->clientWidth())
	{
		x_delta = -(rand() % 3 + 1);
		bounceCount_++;
	}
	if (ball->getY() + frameHeight_ >= theGame->window()->clientHeight())
	{
		y_delta = -(rand() % 3 + 1);
		bounceCount_++;
	}

	if (bounceCount_ < 10)
	{
		return GE161::Game::CONTINUE_SCENE;
	}
	else     // bounced out
	{
		return -1;  // stop game
	}
}
