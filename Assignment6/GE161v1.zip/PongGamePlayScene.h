//PongGamePlayScene.h

#pragma once

#include "Pong.h"
#include "Scene.h"
#include "GameObject.h"

class PongGamePlayScene : public GE161::Scene
{
public:
	PongGamePlayScene(Pong* theGame);
	~PongGamePlayScene();

	bool setup();
	int draw();

private:
	Pong* theGame;
	GE161::GameObject* ball;
	int frameWidth_;
	int frameHeight_;
	int bounceCount_;

	int x_delta, y_delta;
};

