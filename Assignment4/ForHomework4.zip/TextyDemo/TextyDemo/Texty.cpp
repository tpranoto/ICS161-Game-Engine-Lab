// Texty.cpp

#include "Texty.h"   // You can add or remove #include files as needed.
#include <iostream>
#include <sstream>
#include "Windows.h"

